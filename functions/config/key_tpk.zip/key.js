/*!
 * Concomsis JMY
 * Copyright(c) 2009-2019 Juan Manuel Martinez Garcias
 * MIT Licensed
 */
'use strict';

/**
 * Module dependencies.
 */


/**
 * Module exports.
 * @public
 */
exports.key = {
    servidor:"https://comsis.mx/api/auth/v1/",
    path:"tecnopack-corrugados/us-central1/api/",
    localhost:true,
    //localhost_api:"https://us-central1-encouraging-mix-111109.cloudfunctions.net/da/",
    localhost_api:"http://localhost:5001/encouraging-mix-111109/us-central1/api/",
    api_server:"e2ad454bea7d919f0fc411a8b885580c", 
    api:"451c57d8a3eab8592429c123664373d8",
    apikey:"e2ce3af1b9e3086ab89d09f2cc3bd27a",
  };

/**
 * Module variables.
 * @private
 */
